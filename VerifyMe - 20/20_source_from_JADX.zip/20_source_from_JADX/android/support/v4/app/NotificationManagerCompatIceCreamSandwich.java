package android.support.v4.app;

class NotificationManagerCompatIceCreamSandwich {
    static final int SIDE_CHANNEL_BIND_FLAGS = 33;

    NotificationManagerCompatIceCreamSandwich() {
    }
}
