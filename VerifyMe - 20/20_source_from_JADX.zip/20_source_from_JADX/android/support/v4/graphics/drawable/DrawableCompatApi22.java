package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatApi22 {
    DrawableCompatApi22() {
    }

    public static Drawable wrapForTinting(Drawable drawable) {
        return drawable;
    }
}
